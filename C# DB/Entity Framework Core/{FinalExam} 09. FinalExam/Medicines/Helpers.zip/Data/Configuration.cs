﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = "Server=DESKTOP-GH19G10\\SQLEXPRESS;Database=Medicine;Integrated Security=True;";
    }
}

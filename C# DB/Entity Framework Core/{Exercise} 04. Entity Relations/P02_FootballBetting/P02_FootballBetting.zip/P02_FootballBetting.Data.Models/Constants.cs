﻿namespace P02_FootballBetting.Data.Models
{
    public static class Constants
    {
        public const int ColorNameMax = 100;
        public const int PositionNameMaxLength = 50;
        public const int TeamNameMaxLength = 256;
        public const int TeamInitialsMaxLength = 3;
    }
}

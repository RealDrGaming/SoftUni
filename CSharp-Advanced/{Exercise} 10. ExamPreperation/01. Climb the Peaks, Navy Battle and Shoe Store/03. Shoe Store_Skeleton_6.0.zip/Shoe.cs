﻿namespace ShoeStore
{
    public class Shoe
    {
    }
}

﻿namespace SoftUniKindergarten
{
    public class Child
    {
        
    }
}
